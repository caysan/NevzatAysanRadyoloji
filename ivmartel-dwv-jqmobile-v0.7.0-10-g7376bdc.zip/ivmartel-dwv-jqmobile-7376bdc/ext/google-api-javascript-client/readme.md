Third Party: google-api-javascript-client
=========================================

* Web: https://github.com/google/google-api-javascript-client
* Version: ??
* Date: ?? (downloaded on 2021/03/09)
* Download: [client.js](https://apis.google.com/js/client.js) and [api.js](https://apis.google.com/js/api.js)
* License: [Apache-2](https://opensource.org/licenses/Apache-2.0)
* Description: Google APIs Client Library for JavaScript.
* Purpose for dwv: Connect with google.
